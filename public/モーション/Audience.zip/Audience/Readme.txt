Read and agree with ALL terms of use written in this text file before using this Motion Data.
If you do not agree with all terms of use,or if you do not understand any part of this terms of use text file,you are NOT allowed to use this Motion Data.

●オーディエンス（商用利用可能）

○Audience(Allow commercial use)

●当データについて（VMD）
MikuMikuDance（樋口M様）用モーションデータです。
新規でモーションキャプチャーしたデータを元に音街ウナ（公式モデル）にて最適化修正されています。
他のモデルにご利用頂く為には追加修正が必要な場合があります。
当モーションデータは商用にもご利用頂けます。

○About This Data(VMD)
This Motion Data for MikuMikuDace.
Based on the new motion capture data has been optimized fixed in Otomachi Una(
Officilal Model).
In order to receive your use to other models you may add necessary modifications.
The motion data is possible to commercial use.

●当データについて（BVH）
モーションキャプチャーの生データです。
MMDにそのまま使う事は出来ません。
対応しているアプリケーションにてご利用ください。

○About This Data(BVH)
This is the raw data of the motion capture.
It can not be used to MMD
Please use in and supported applications.

●改造再配布について
著作権は放棄しておりませんので、当モーションデータをそのままの再配布はご遠慮ください。
改造再配布する場合は、名称及び本規約を継承し本テキストを添付してください。

○About the remodeling and re-distribution
We will continue to have the copyright.
Do NOT distribute her if you have not made any changes.
You may distribute this MMD Motion Data,ONLY if you have made edits to her.
Naming and this text file must be included.

●免責事項
当モデルデータを使用して発生した何らかのトラブルにおいて、当方は一切の責任を負いません。

○Disclaimers
I can not be held liable or responsible for any damages caused by using this data.

●禁止事項
公序良俗に反する利用。
当モーションデータをそのまま再配布。

○Prohibited matter
Do not use this Motion Data for works which include obscene, grotesque, and violent content.
Do NOT distribute her if you have not made any changes.

●音街ウナ公式ウェブサイト
http://otomachiuna.jp/

○Otomachi Una Official Website
http://otomachiuna.jp/

©MTK
